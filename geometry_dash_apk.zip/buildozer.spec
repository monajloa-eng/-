[app]

# Назва та пакет
title = Geometry Dash
package.name = geodash
package.domain = org.example

# Головний файл
source.dir = .
source.include_exts = py,png,jpg,kv,atlas

# Версія
version = 1.0

# Залежності
requirements = python3,kivy

# Орієнтація — альбомна (як справжній GD)
orientation = landscape

# Повноекранний режим
fullscreen = 1

# Android налаштування
android.permissions = VIBRATE
android.api = 33
android.minapi = 21
android.ndk = 25b
android.sdk = 33
android.archs = arm64-v8a, armeabi-v7a

# Іконка (якщо є)
# icon.filename = %(source.dir)s/icon.png

# Назва в системі
android.app_name = GeoDash

[buildozer]
log_level = 2
warn_on_root = 1
