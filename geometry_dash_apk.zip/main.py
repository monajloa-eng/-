# ╔══════════════════════════════════════════════════════════════╗
# ║         GEOMETRY DASH  —  Kivy  (Android / Pydroid 3)       ║
# ║  Встановити: pip install kivy                                ║
# ╚══════════════════════════════════════════════════════════════╝

import random
import math

from kivy.app import App
from kivy.uix.widget import Widget
from kivy.graphics import (
    Color, Rectangle, Triangle, Line, Ellipse,
    RoundedRectangle
)
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label

# ── Розміри ──────────────────────────────────────────────────────────────────
W = Window.width
H = Window.height

TILE        = max(44, int(H / 11))
GROUND_Y    = TILE + 30
CEIL_Y      = H - TILE - 20
PLAYER_SIZE = TILE - 6
SPEED_BASE  = W / 140.0
FPS         = 60

# ── Кольори (r,g,b,a  від 0 до 1) ────────────────────────────────────────────
def c(r, g, b, a=1): return (r/255, g/255, b/255, a)

BG_BOT   = c(8,   8,  28)
BG_TOP   = c(14, 14,  48)
GND_COL  = c(18, 18,  58)
GND_LINE = c(0,  220, 220)
CEI_LINE = c(60, 100, 255)

CY = c(0,   230, 230)      # cyan
YE = c(255, 210,   0)      # yellow
MA = c(230,   0, 160)      # magenta
GR = c(0,   210,  80)      # green
OR = c(255, 110,   0)      # orange
WH = c(245, 245, 245)      # white
RE = c(255,  50,  50)      # red
BL = c(60,  110, 255)      # blue
PK = c(240,  90, 190)      # pink

NEON = [CY, YE, MA, GR, OR, PK, BL]

def lerp(a, b, t):
    return a + (b - a) * t

def lerp_col(ca, cb, t):
    return tuple(lerp(ca[i], cb[i], t) for i in range(4))

# ═══════════════════════════════════════════════════════════════════════════════
#  СТАН ГРИ
# ═══════════════════════════════════════════════════════════════════════════════
STATE_MENU = 0
STATE_PLAY = 1
STATE_DEAD = 2

# ═══════════════════════════════════════════════════════════════════════════════
#  ПЕРЕШКОДИ
# ═══════════════════════════════════════════════════════════════════════════════
class Spike:
    def __init__(self, x):
        self.x = float(x)
        self.w = TILE
        self.h = TILE

    def move(self, speed): self.x -= speed

    def hitbox(self):
        pad = TILE // 5
        return (self.x + pad, GROUND_Y,
                self.w - pad*2, self.h - pad)

    def draw(self, canvas):
        bx, by = self.x, GROUND_Y
        # Тінь
        with canvas:
            Color(*MA, 0.4)
            Triangle(points=[
                bx + self.w//2 + 2, by + self.h - 2,
                bx + self.w - 2,    by + 2,
                bx + 4,             by + 2,
            ])
            Color(*MA)
            Triangle(points=[
                bx + self.w//2, by + self.h,
                bx + self.w - 3, by,
                bx + 3,          by,
            ])
            Color(*WH)
            Line(points=[
                bx + self.w//2, by + self.h,
                bx + self.w - 3, by,
                bx + 3,          by,
                bx + self.w//2, by + self.h,
            ], width=1.5)


class Block:
    def __init__(self, x, stack=1):
        self.x     = float(x)
        self.stack = stack

    def move(self, speed): self.x -= speed

    def hitbox(self):
        return (self.x, GROUND_Y, TILE, TILE * self.stack)

    def draw(self, canvas):
        with canvas:
            for i in range(self.stack):
                bx = self.x
                by = GROUND_Y + TILE * i
                Color(*c(0, 50, 80))
                RoundedRectangle(pos=(bx+2, by+2),
                                  size=(TILE-2, TILE-2), radius=[5])
                Color(*CY)
                RoundedRectangle(pos=(bx, by),
                                  size=(TILE-2, TILE-2), radius=[5])
                Color(*WH)
                Line(rectangle=(bx, by, TILE-2, TILE-2),
                     width=1.5)
                # Хрестик
                cx2 = bx + (TILE-2)//2
                cy2 = by + (TILE-2)//2
                Color(*WH, 0.35)
                Line(points=[cx2-8, cy2-8, cx2+8, cy2+8], width=1)
                Line(points=[cx2+8, cy2-8, cx2-8, cy2+8], width=1)


class DoubleSpike:
    def __init__(self, x):
        self.x  = float(x)
        self.s1 = Spike(x)
        self.s2 = Spike(x + TILE + 8)

    def move(self, speed):
        self.x -= speed
        self.s1.move(speed)
        self.s2.move(speed)

    def hitbox(self):
        h1 = self.s1.hitbox()
        h2 = self.s2.hitbox()
        lx = min(h1[0], h2[0])
        rx = max(h1[0]+h1[2], h2[0]+h2[2])
        return (lx, GROUND_Y, rx-lx, TILE)

    def draw(self, canvas):
        self.s1.draw(canvas)
        self.s2.draw(canvas)


class Platform:
    def __init__(self, x, y_off=2):
        self.x = float(x)
        self.y = GROUND_Y + TILE * y_off + TILE // 2
        self.w = TILE * 3
        self.h = TILE // 2

    def move(self, speed): self.x -= speed

    def hitbox(self):
        return (self.x, self.y, self.w, self.h)

    def draw(self, canvas):
        with canvas:
            Color(*c(0, 80, 30))
            RoundedRectangle(pos=(self.x+2, self.y-2),
                              size=(self.w, self.h), radius=[6])
            Color(*GR)
            RoundedRectangle(pos=(self.x, self.y),
                              size=(self.w, self.h), radius=[6])
            Color(*WH)
            Line(rounded_rectangle=(self.x, self.y,
                                    self.w, self.h, 6), width=1.5)


# ═══════════════════════════════════════════════════════════════════════════════
#  ГРАВЕЦЬ
# ═══════════════════════════════════════════════════════════════════════════════
class Player:
    def __init__(self):
        self.reset()

    def reset(self):
        self.x         = W * 0.18
        self.y         = float(GROUND_Y + PLAYER_SIZE)
        self.vy        = 0.0
        self.on_ground = False
        self.angle     = 0.0
        self.trail     = []
        self.dead      = False
        self._t        = 0

    def jump(self):
        if self.on_ground:
            self.vy        = TILE * 0.295 + 8.5
            self.on_ground = False
            return True
        return False

    def update(self, obstacles, dt):
        gravity = TILE * 0.022
        self.vy -= gravity
        self.y  += self.vy

        # Земля
        if self.y <= GROUND_Y + PLAYER_SIZE:
            self.y         = float(GROUND_Y + PLAYER_SIZE)
            self.vy        = 0.0
            self.on_ground = True
        else:
            self.on_ground = False

        # Стеля
        if self.y >= CEIL_Y:
            self.y  = float(CEIL_Y)
            self.vy = -3.0

        # Кут
        if not self.on_ground:
            self.angle = (self.angle - 7) % 360
        else:
            target = round(self.angle / 90) * 90
            self.angle += (target - self.angle) * 0.3

        # Трейл
        self._t += 1
        if self._t % 2 == 0:
            self.trail.append((self.x + PLAYER_SIZE/2,
                                self.y - PLAYER_SIZE/2))
            if len(self.trail) > 12:
                self.trail.pop(0)

        # Хітбокс
        pad = PLAYER_SIZE // 5
        px  = self.x + pad
        py  = self.y - PLAYER_SIZE + pad
        pw  = PLAYER_SIZE - pad*2
        ph  = PLAYER_SIZE - pad*2

        for obs in obstacles:
            ox, oy, ow, oh = obs.hitbox()
            if (px < ox+ow and px+pw > ox and
                    py < oy+oh and py+ph > oy):
                self.dead = True
                return

    def draw(self, canvas):
        # Трейл
        n = len(self.trail)
        with canvas:
            for i, (tx, ty) in enumerate(self.trail):
                t   = i / max(1, n)
                sz  = max(2, int(PLAYER_SIZE * 0.28 * t))
                Color(YE[0], YE[1], YE[2], t * 0.6)
                Rectangle(pos=(tx - sz, ty - sz), size=(sz*2, sz*2))

        # Тіло (пряма квадратна форма без повороту для швидкості)
        cx = self.x + PLAYER_SIZE / 2
        cy = self.y - PLAYER_SIZE / 2
        with canvas:
            # Тінь
            Color(*YE, 0.3)
            RoundedRectangle(pos=(self.x+4, self.y-PLAYER_SIZE-4),
                              size=(PLAYER_SIZE, PLAYER_SIZE), radius=[8])
            # Тіло
            Color(*YE)
            RoundedRectangle(pos=(self.x, self.y-PLAYER_SIZE),
                              size=(PLAYER_SIZE, PLAYER_SIZE), radius=[8])
            Color(*WH)
            Line(rounded_rectangle=(self.x, self.y-PLAYER_SIZE,
                                    PLAYER_SIZE, PLAYER_SIZE, 8), width=2)
            # Промені
            r = PLAYER_SIZE // 4
            Color(*WH, 0.7)
            for a in range(0, 360, 72):
                rad = math.radians(a + self.angle)
                ex  = cx + r * math.cos(rad)
                ey  = cy + r * math.sin(rad)
                Line(points=[cx, cy, ex, ey], width=1.5)
            Color(*WH)
            Ellipse(pos=(cx - PLAYER_SIZE//8, cy - PLAYER_SIZE//8),
                    size=(PLAYER_SIZE//4, PLAYER_SIZE//4))


# ═══════════════════════════════════════════════════════════════════════════════
#  ЧАСТИНКИ
# ═══════════════════════════════════════════════════════════════════════════════
class Particle:
    __slots__ = ('x','y','vx','vy','life','max_life','color','size')

    def __init__(self, x, y, color, vx, vy, life, size):
        self.x=float(x); self.y=float(y)
        self.vx=vx; self.vy=vy
        self.life=life; self.max_life=life
        self.color=color; self.size=size

    def update(self):
        self.x  += self.vx
        self.y  += self.vy
        self.vy -= 0.3
        self.life -= 1

    def draw(self, canvas):
        t  = self.life / self.max_life
        sz = max(1, int(self.size * t))
        with canvas:
            Color(*self.color[:3], t * 0.9)
            Rectangle(pos=(self.x-sz, self.y-sz), size=(sz*2, sz*2))


# ═══════════════════════════════════════════════════════════════════════════════
#  ГЕНЕРАЦІЯ РІВНЯ
# ═══════════════════════════════════════════════════════════════════════════════
def generate_chunk(start_x, score):
    obs  = []
    diff = min(1.0, score / 5000)
    x    = float(start_x)
    end  = start_x + W * 2.5

    while x < end:
        gap = random.randint(int(W*0.22 - diff*W*0.07),
                             int(W*0.40 - diff*W*0.07))
        x  += gap
        r   = random.random()

        if r < 0.30:
            obs.append(Spike(x))
            if diff > 0.35 and random.random() < 0.40:
                obs.append(Spike(x + TILE + 8))
        elif r < 0.52:
            obs.append(Block(x, random.choices([1,2], weights=[6,4])[0]))
        elif r < 0.70:
            obs.append(DoubleSpike(x))
        else:
            obs.append(Platform(x, random.choice([2, 3])))

    return obs


# ═══════════════════════════════════════════════════════════════════════════════
#  ГОЛОВНИЙ ВІДЖЕТ
# ═══════════════════════════════════════════════════════════════════════════════
class GameWidget(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.state       = STATE_MENU
        self.player      = Player()
        self.obstacles   = []
        self.particles   = []
        self.score       = 0
        self.best        = 0
        self.speed       = SPEED_BASE
        self.grid_off    = 0.0
        self.death_timer = 0
        self.frame       = 0
        self._stars      = self._make_stars()

        # Лейбли
        self.lbl_score = Label(text="", font_size=str(int(H/22))+"sp",
                               bold=True, color=(1, 0.85, 0, 1),
                               pos=(10, H-60), size=(W//2, 50))
        self.lbl_best  = Label(text="", font_size=str(int(H/30))+"sp",
                               bold=True, color=(0, 0.9, 0.9, 1),
                               pos=(10, H-100), size=(W//2, 50))
        self.lbl_menu  = Label(text="ТОП або НАТИСНИ — стрибок\n\nESC — вихід",
                               font_size=str(int(H/26))+"sp",
                               bold=True, color=(0.9, 0.9, 1, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 - 80), size=(W, 120))
        self.lbl_start = Label(text="НАТИСНИ ДЛЯ ПОЧАТКУ",
                               font_size=str(int(H/18))+"sp",
                               bold=True, color=(0, 0.9, 0.9, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 - 180), size=(W, 80))
        self.lbl_title = Label(text="GEOMETRY DASH",
                               font_size=str(int(H/10))+"sp",
                               bold=True, color=(1, 0.85, 0, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 + 60), size=(W, 120))
        self.lbl_dead  = Label(text="", font_size=str(int(H/18))+"sp",
                               bold=True, color=(1, 0.2, 0.2, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 + 40), size=(W, 80))
        self.lbl_dscore= Label(text="", font_size=str(int(H/24))+"sp",
                               bold=True, color=(1, 0.85, 0, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 - 40), size=(W, 60))
        self.lbl_dbest = Label(text="", font_size=str(int(H/24))+"sp",
                               bold=True, color=(0.2, 1, 0.4, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 - 110), size=(W, 60))
        self.lbl_retry = Label(text="ТОП/НАТИСНИ — знову   ESC — меню",
                               font_size=str(int(H/30))+"sp",
                               bold=True, color=(0, 0.9, 0.9, 1),
                               halign="center", valign="middle",
                               pos=(0, H//2 - 200), size=(W, 60))

        self._set_state(STATE_MENU)
        Clock.schedule_interval(self.update, 1.0 / FPS)
        Window.bind(on_key_down=self._on_key)
        self.bind(on_touch_down=self._on_touch)

    # ── Зірки ────────────────────────────────────────────────────────────────
    def _make_stars(self):
        stars = []
        for _ in range(60):
            stars.append({
                'x':  random.uniform(0, W),
                'y':  random.uniform(GROUND_Y + TILE, CEIL_Y - TILE),
                'r':  random.uniform(1, 3),
                'col':random.choice(NEON),
                'spd':random.uniform(0.3, 1.0),
            })
        return stars

    # ── Стани ────────────────────────────────────────────────────────────────
    def _set_state(self, s):
        self.state = s
        # Прибираємо всі лейбли
        for lbl in (self.lbl_score, self.lbl_best, self.lbl_menu,
                    self.lbl_start, self.lbl_title, self.lbl_dead,
                    self.lbl_dscore, self.lbl_dbest, self.lbl_retry):
            if lbl.parent:
                self.remove_widget(lbl)

        if s == STATE_MENU:
            self.add_widget(self.lbl_title)
            self.add_widget(self.lbl_menu)
            self.add_widget(self.lbl_start)
            if self.best > 0:
                self.lbl_best.text = f"РЕКОРД: {self.best}"
                self.add_widget(self.lbl_best)
        elif s == STATE_PLAY:
            self.add_widget(self.lbl_score)
            self.add_widget(self.lbl_best)
        elif s == STATE_DEAD:
            self.lbl_dead.text   = "ТИ ЗАГИНУВ!"
            self.lbl_dscore.text = f"РАХУНОК: {self.score}"
            self.lbl_dbest.text  = f"РЕКОРД:  {self.best}"
            self.add_widget(self.lbl_dead)
            self.add_widget(self.lbl_dscore)
            self.add_widget(self.lbl_dbest)
            self.add_widget(self.lbl_retry)

    def _start_game(self):
        self.player.reset()
        self.obstacles   = generate_chunk(W + TILE*3, 0)
        self.score       = 0
        self.speed       = SPEED_BASE
        self.death_timer = 0
        self.particles.clear()
        self._set_state(STATE_PLAY)

    def _do_jump(self):
        if self.player.jump():
            for _ in range(5):
                self.particles.append(Particle(
                    self.player.x + PLAYER_SIZE//2,
                    self.player.y - PLAYER_SIZE,
                    random.choice([YE, CY, WH]),
                    random.uniform(-2.5, 2.5),
                    random.uniform(1.0, 4.0),
                    random.randint(10, 22),
                    random.randint(3, 7)))

    # ── Введення ─────────────────────────────────────────────────────────────
    def _on_key(self, window, key, *args):
        ESC   = 27
        SPACE = 32
        UP    = 273

        if key == ESC:
            if self.state in (STATE_PLAY, STATE_DEAD):
                self._set_state(STATE_MENU)
            else:
                App.get_running_app().stop()

        if key in (SPACE, UP):
            if self.state == STATE_MENU:
                self._start_game()
            elif self.state == STATE_PLAY:
                self._do_jump()
            elif self.state == STATE_DEAD and self.death_timer > 30:
                self._start_game()

    def _on_touch(self, widget, touch):
        if self.state == STATE_MENU:
            self._start_game()
        elif self.state == STATE_PLAY:
            self._do_jump()
        elif self.state == STATE_DEAD and self.death_timer > 30:
            self._start_game()

    # ── Оновлення ─────────────────────────────────────────────────────────────
    def update(self, dt):
        self.frame += 1

        if self.state == STATE_PLAY:
            self.score += int(self.speed)
            self.speed  = SPEED_BASE + self.score / 9000.0
            self.grid_off = (self.grid_off + self.speed) % TILE

            prev = self.player.dead
            self.player.update(self.obstacles, dt)

            if self.player.dead and not prev:
                self.best        = max(self.best, self.score)
                self.death_timer = 0
                # Вибух
                for _ in range(25):
                    self.particles.append(Particle(
                        self.player.x + PLAYER_SIZE//2,
                        self.player.y - PLAYER_SIZE//2,
                        random.choice(NEON),
                        random.uniform(-7, 7),
                        random.uniform(-2, 8),
                        random.randint(25, 60),
                        random.randint(4, 12)))
                self._set_state(STATE_DEAD)

            for obs in self.obstacles:
                obs.move(self.speed)
            self.obstacles = [o for o in self.obstacles if o.x > -(TILE*8)]

            rightmost = max((o.x for o in self.obstacles), default=float(W))
            if rightmost < W * 1.8:
                self.obstacles += generate_chunk(rightmost + TILE*4, self.score)

            # Частинка бігу
            if random.random() < 0.25:
                self.particles.append(Particle(
                    self.player.x + 4,
                    self.player.y - PLAYER_SIZE + 4,
                    random.choice([YE, OR]),
                    random.uniform(-1.5, -0.2),
                    random.uniform(-0.5, 1.2),
                    random.randint(5, 14),
                    random.randint(2, 4)))

            # HUD
            self.lbl_score.text = f"РАХУНОК: {self.score}"
            self.lbl_best.text  = f"РЕКОРД: {self.best}"

        elif self.state == STATE_DEAD:
            self.death_timer += 1

        # Зірки
        for s in self._stars:
            s['x'] = (s['x'] - s['spd'] * (self.speed / SPEED_BASE)) % W

        # Частинки
        i = 0
        while i < len(self.particles):
            self.particles[i].update()
            if self.particles[i].life <= 0:
                self.particles.pop(i)
            else:
                i += 1

        self.canvas.clear()
        self._draw()

    # ── Малювання ─────────────────────────────────────────────────────────────
    def _draw(self):
        c = self.canvas

        # Фон
        with c:
            Color(*BG_BOT)
            Rectangle(pos=(0, 0), size=(W, H))
            # Градієнт смугами
            rows = 8
            rh   = H // rows
            for i in range(rows):
                t   = i / rows
                col = lerp_col(BG_BOT, BG_TOP, t)
                Color(*col)
                Rectangle(pos=(0, i*rh), size=(W, rh+2))

        # Зірки
        with c:
            for star in self._stars:
                dim = (star['col'][0]*0.25, star['col'][1]*0.25,
                       star['col'][2]*0.25, 1)
                Color(*dim)
                r = int(star['r'])
                Ellipse(pos=(int(star['x'])-r, int(star['y'])-r),
                        size=(r*2, r*2))

        # Сітка
        go = int(self.grid_off)
        with c:
            Color(0.11, 0.13, 0.28, 1)
            for gx in range(-go, W + TILE, TILE):
                Line(points=[gx, GROUND_Y, gx, CEIL_Y], width=1)
            for gy in range(GROUND_Y, CEIL_Y, TILE):
                Line(points=[0, gy, W, gy], width=1)

        # Земля
        with c:
            Color(*GND_COL)
            Rectangle(pos=(0, 0), size=(W, GROUND_Y))
            Color(*GND_LINE)
            Line(points=[0, GROUND_Y, W, GROUND_Y], width=2.5)
            # Смуги
            Color(0.09, 0.09, 0.27)
            for sx in range(0, W, TILE*2):
                Rectangle(pos=(sx, 0), size=(TILE, GROUND_Y))

        # Стеля
        with c:
            Color(*GND_COL)
            Rectangle(pos=(0, CEIL_Y), size=(W, H - CEIL_Y))
            Color(*CEI_LINE)
            Line(points=[0, CEIL_Y, W, CEIL_Y], width=2.5)

        # Перешкоди
        for obs in self.obstacles:
            obs.draw(c)

        # Гравець
        if not self.player.dead:
            self.player.draw(c)

        # Частинки
        for p in self.particles:
            p.draw(c)

        # Смуга швидкості
        if self.state == STATE_PLAY:
            bm = W // 5
            bw = int(bm * min(1.0, (self.speed - SPEED_BASE) / 6.0))
            with c:
                Color(0.1, 0.1, 0.24)
                RoundedRectangle(pos=(W-bm-20, H-44), size=(bm, 16), radius=[8])
                if bw > 0:
                    Color(*OR)
                    RoundedRectangle(pos=(W-bm-20, H-44), size=(bw, 16), radius=[8])

        # Затемнення при смерті
        if self.state == STATE_DEAD:
            with c:
                Color(0, 0, 0, 0.55)
                Rectangle(pos=(0, 0), size=(W, H))


# ═══════════════════════════════════════════════════════════════════════════════
#  ЗАСТОСУНОК
# ═══════════════════════════════════════════════════════════════════════════════
class GeoDashApp(App):
    def build(self):
        Window.clearcolor = (0, 0, 0, 1)
        Window.bind(on_keyboard=self._back)
        root = FloatLayout()
        self.game = GameWidget(size=(W, H), pos=(0, 0))
        root.add_widget(self.game)
        return root

    def _back(self, window, key, *args):
        if key == 27:
            if self.game.state in (STATE_PLAY, STATE_DEAD):
                self.game._set_state(STATE_MENU)
            else:
                self.stop()
            return True
        return False


if __name__ == "__main__":
    GeoDashApp().run()
